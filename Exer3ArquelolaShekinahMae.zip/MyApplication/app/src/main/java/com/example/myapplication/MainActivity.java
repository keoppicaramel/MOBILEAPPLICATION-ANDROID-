package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Button;
import android.view.View.*;



public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2,ed3,ed4,ed5,ed6,ed7,ed8,ed9,ed10,ed11,
            ed12,ed13,ed14,ed15,ed16,ed17,ed18,ed19,ed20,ed21,ed22,
            ed23,ed24,ed25,ed26,ed27,ed28,ed29,ed30,ed31,ed32,ed33;
    Button btn1,btn2;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);




        ed1 = findViewById(R.id.stname);
        ed2 = findViewById(R.id.WW0);
        ed3 = findViewById(R.id.WW1);
        ed4 = findViewById(R.id.WW2);
        ed5 = findViewById(R.id.WW3);
        ed6 = findViewById(R.id.WW4);
        ed7 = findViewById(R.id.WW5);
        ed8 = findViewById(R.id.PT0);
        ed9 = findViewById(R.id.PT1);
        ed10 = findViewById(R.id.PT2);
        ed11 = findViewById(R.id.PT3);
        ed12 = findViewById(R.id.PT4);
        ed13 = findViewById(R.id.PT5);
        ed14 = findViewById(R.id.TA);
        ed15 = findViewById(R.id.TA1);
        ed16 = findViewById(R.id.W0);
        ed17= findViewById(R.id.W1);
        ed18 = findViewById(R.id.W2);
        ed19 = findViewById(R.id.W3);
        ed20 = findViewById(R.id.W4);
        ed21 = findViewById(R.id.W5);
        ed22 = findViewById(R.id.PTS0);
        ed23 = findViewById(R.id.PTS1);
        ed24 = findViewById(R.id.PTS2);
        ed25 = findViewById(R.id.PTS3);
        ed26 = findViewById(R.id.PTS4);
        ed27 = findViewById(R.id.PTS5);
        ed28 = findViewById(R.id.TAS);
        ed29 = findViewById(R.id.TA2);
        ed30 = findViewById(R.id.MIDG);
        ed31 = findViewById(R.id.FINALG);
        ed32 = findViewById(R.id.FINALSUBG);
        ed33= findViewById(R.id.grade);



        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                stmarks();
            }

        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
            }
        });

    }


    public void stmarks()
    {

        int M1,M2,M3,M4,M5,M6,M7,M8,M9,M10,M11,M12,M13,M14,
                M15,M16,M17,M18,M19,M20,M21,M22;
        double mw,mp,mta,MIDG,fw,fp,fta,FINALG,FINALSUBG;
        String grade;
        M1= Integer.parseInt(ed3.getText().toString());
        M2 = Integer.parseInt(ed4.getText().toString());
        M3 = Integer.parseInt(ed5.getText().toString());
        M4 = Integer.parseInt(ed6.getText().toString());
        M5 = Integer.parseInt(ed7.getText().toString());
        M6 = Integer.parseInt(ed9.getText().toString());
        M7 = Integer.parseInt(ed10.getText().toString());
        M8 = Integer.parseInt(ed11.getText().toString());
        M9 = Integer.parseInt(ed12.getText().toString());
        M10 = Integer.parseInt(ed13.getText().toString());
        M11 = Integer.parseInt(ed15.getText().toString());
        M12 = Integer.parseInt(ed17.getText().toString());
        M13 = Integer.parseInt(ed18.getText().toString());
        M14 = Integer.parseInt(ed19.getText().toString());
        M15 = Integer.parseInt(ed20.getText().toString());
        M16 = Integer.parseInt(ed21.getText().toString());
        M17 = Integer.parseInt(ed23.getText().toString());
        M18 = Integer.parseInt(ed24.getText().toString());
        M19 = Integer.parseInt(ed25.getText().toString());
        M20 = Integer.parseInt(ed26.getText().toString());
        M21 = Integer.parseInt(ed27.getText().toString());
        M22 = Integer.parseInt(ed29.getText().toString());

        mw = ((M1+M2+M3+M4+M5)/5 * 0.25);
        fw = ((M12+M13+M14+M15+M16)/5 * 0.25);
        ed2.setText(String.valueOf(mw));
        ed16.setText(String.valueOf(fw));


        mp = ((M6+M7+M8+M9+M10)/5 * 0.45);
        fp = ((M17+M18+M19+M20+M21)/5 * 0.45);
        ed8.setText(String.valueOf(mp));
        ed22.setText(String.valueOf(fp));

        mta = (M11 * 0.30);
        fta = (M22 * 0.30);
        ed14.setText(String.valueOf(mta));
        ed28.setText(String.valueOf(fta));

        MIDG = (mw+mp+mta);
        FINALG = (fw+fp+fta);
        ed30.setText(String.valueOf(MIDG));
        ed31.setText(String.valueOf(FINALG));

        FINALSUBG = ((MIDG+FINALG)/2);
        ed32.setText(String.valueOf(FINALSUBG));

        if(FINALSUBG >= 97 && FINALSUBG== 100)
        {
            ed33.setText("1.00 - Highly Excellent");
        }
        else if(FINALSUBG >= 94 && FINALSUBG <=96)
        {
            ed33.setText("1.25 - Excellent");
        }

        else if(FINALSUBG >= 91 && FINALSUBG <= 93)
        {
            ed33.setText("1.50 - Very Superior");
        }

        else if(FINALSUBG >=  88 && FINALSUBG <= 90)
        {
            ed33.setText("1.75 - Superior");
        }

        else if(FINALSUBG >=  85 && FINALSUBG <= 87)
        {
            ed33.setText("2.00 - Very Good");
        }

        else if(FINALSUBG >=  82 && FINALSUBG<= 84)
        {
            ed33.setText("2.25 - Good");
        }

        else if(FINALSUBG >=  79 && FINALSUBG <= 81)
        {
            ed33.setText("2.50 - Satisfactory");
        }

        else if(FINALSUBG >=  76 && FINALSUBG <= 78)
        {
            ed33.setText("2.75 - Fair");
        }

        else if(FINALSUBG == 75)
        {
            ed33.setText("3.00 - Passed");
        }
        else
        {
            ed33.setText("5.00 - Failed");
        }

    }



    public void clear()
    {
        ed1.setText("");
        ed2.setText("");
        ed3.setText("");
        ed4.setText("");
        ed5.setText("");
        ed6.setText("");
        ed7.setText("");
        ed8.setText("");
        ed9.setText("");
        ed10.setText("");
        ed11.setText("");
        ed12.setText("");
        ed13.setText("");
        ed14.setText("");
        ed15.setText("");
        ed16.setText("");
        ed17.setText("");
        ed18.setText("");
        ed19.setText("");
        ed20.setText("");
        ed21.setText("");
        ed22.setText("");
        ed23.setText("");
        ed24.setText("");
        ed25.setText("");
        ed26.setText("");
        ed27.setText("");
        ed28.setText("");
        ed29.setText("");
        ed30.setText("");
        ed31.setText("");
        ed32.setText("");
        ed33.setText("");



    }
}

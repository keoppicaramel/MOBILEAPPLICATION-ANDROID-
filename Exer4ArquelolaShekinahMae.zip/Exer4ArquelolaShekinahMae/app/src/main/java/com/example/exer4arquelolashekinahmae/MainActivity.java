package com.example.exer4arquelolashekinahmae;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    EditText edtfullname, edtstudentno, edtmidtermgrade, edtfinaltermgrade, edtequivalent, edtdescription, edtfinalgrade;
    Button btncompute, btnclear, btnsave;
    DatabaseReference exer4arquelolashekinahmae;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);

        edtfullname = findViewById (R.id.edtFullname);
        edtstudentno = findViewById (R.id.edtStudno);
        edtmidtermgrade = findViewById (R.id.edtMidtermgrade);
        edtfinaltermgrade = findViewById (R.id.edtFinaltermgrade);
        edtequivalent = findViewById (R.id.edtEquivalent);
        edtdescription = findViewById (R.id.edtDescription);
        edtfinalgrade = findViewById (R.id.edtFinalgrade);


        btncompute = findViewById (R.id.btnCompute);
        btnsave = findViewById (R.id.btnSave);
        btnclear = findViewById (R.id.btnClear);
        exer4arquelolashekinahmae = FirebaseDatabase.getInstance().getReference().child("Students");

        btnclear.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {
                edtfullname.setText ("");
                edtdescription.setText ("");
                edtequivalent.setText ("");
                edtmidtermgrade.setText ("");
                edtfinaltermgrade.setText ("");
                edtstudentno.setText ("");
                edtfinalgrade.setText ("");
            }
        });

        btncompute.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {
                double midterm = Double.parseDouble (edtmidtermgrade.getText ().toString ());
                double finalterm = Double.parseDouble (edtfinaltermgrade.getText ().toString ());
                double finalgrade = (midterm + finalterm) / 2;
                edtfinalgrade.setText (String.valueOf (finalgrade));
                if(finalgrade>=97 && finalgrade<=100){
                    edtequivalent.setText ("1.00");
                    edtdescription.setText ("Highly Excellent");
                }
                else if (finalgrade>=94 && finalgrade<=96){
                    edtequivalent.setText ("1.25");
                    edtdescription.setText ("Excellent");
                }
                else if (finalgrade>=91 && finalgrade<=93){
                    edtequivalent.setText ("1.50");
                    edtdescription.setText ("Super Superior");
                }
                else if (finalgrade>=88 && finalgrade<=90){
                    edtequivalent.setText ("1.75");
                    edtdescription.setText ("Superior");
                }
                else if (finalgrade>=85 && finalgrade<=87){
                    edtequivalent.setText ("2.00");
                    edtdescription.setText ("Very Good");
                }
                else if (finalgrade>=82 && finalgrade<=84){
                    edtequivalent.setText ("2.25");
                    edtdescription.setText ("Good");
                }
                else if (finalgrade>=79 && finalgrade<=81){
                    edtequivalent.setText ("2.50");
                    edtdescription.setText ("Satisfaction");
                }
                else if (finalgrade>=76 && finalgrade<=78){
                    edtequivalent.setText ("2.75");
                    edtdescription.setText ("Fair");
                }
                else if (finalgrade==75){
                    edtequivalent.setText ("3.00");
                    edtdescription.setText ("Fairly Passed");
                }
                else if (finalgrade<75){
                    edtequivalent.setText ("5.00");
                    edtdescription.setText ("Failed");
                }
            }
        });

        btnsave.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {
                insertStudentData();
            }
        });
    }
    private void insertStudentData(){
        String fullname = edtfullname.getText().toString();
        String studentno = edtstudentno.getText().toString();
        String mtg = edtmidtermgrade.getText().toString();
        String ftg = edtfinaltermgrade.getText().toString();
        String fg = edtfinalgrade.getText().toString();
        String equ = edtequivalent.getText().toString();
        String des = edtdescription.getText().toString();

        Students students = new Students (fullname,studentno,mtg,ftg,fg,equ,des);
        exer4arquelolashekinahmae.push().setValue (students);


        Toast.makeText (MainActivity.this, "Data Save", Toast.LENGTH_SHORT).show ();
    }
}


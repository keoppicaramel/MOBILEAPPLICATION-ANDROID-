package com.example.exer4arquelolashekinahmae;

public class Students {
    String fullname;
    String studentno;
    String mtg;
    String ftg;
    String fg;
    String equ;
    String des;

    public Students(String fullname, String studentno, String mtg, String ftg, String fg, String equ, String des) {
        this.fullname = fullname;
        this.studentno = studentno;
        this.mtg = mtg;
        this.ftg = ftg;
        this.fg = fg;
        this.equ = equ;
        this.des = des;
    }

    public String getFullname() {
        return fullname;
    }

    public String getStudentno() {
        return studentno;
    }

    public String getMtg() {
        return mtg;
    }

    public String getFtg() {
        return ftg;
    }

    public String getFg() {
        return fg;
    }

    public String getEqu() {
        return equ;
    }

    public String getDes() {
        return des;
    }
}
